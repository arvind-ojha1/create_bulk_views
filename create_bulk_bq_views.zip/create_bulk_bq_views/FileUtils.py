import os
import logging as log
class FileUtils():
    
    def createDir(dir):
        try: 
            os.makedirs(dir)
        except:
            log.error("Failed to create "+dir+"_view. It may already exist")
            
            
    def writeContentToFile(filePath, content, mode="w"):
        try: 
            with open(filePath, mode) as file:
                file.write(content)
        except Exception as error:
            log.error("Uanle to write file:"+file + "with error:"+ error)
                
        
        