import shutil
import os
from FileUtils import *
import json
from QueryBuilder import *
import threading
from TerraformUtil import *

class DatasetTableViewsProcessor():
    
    def authorizeView(self, datasetDirPath, tfVarsAsPyObject):
        projectId = tfVarsAsPyObject["project_id"]
        datasetId= tfVarsAsPyObject["dataset_id"]
        authViewsPyObject =[]
        for table in tfVarsAsPyObject["tables"].keys():
            newAuthDict = {}
            newAuthDict["project_id"] =projectId
            newAuthDict["dataset_id"] = datasetId
            newAuthDict["table_id"] = table+"_view"
            authViewsPyObject.append(newAuthDict)
        authorize_view = {}
        authorize_view["authorize_view"] = authViewsPyObject
        tfVarsFilePath = os.path.join(datasetDirPath, "terraform.tfvars")
        tfUtil = TerraformUtil(tfVarsFilePath)
        authorizeViewContent = tfUtil.getTfVarFromPyObject(authorize_view)
        authorizeViewContent = "\n"+authorizeViewContent.replace(",]","]")
        FileUtils.writeContentToFile(tfVarsFilePath,authorizeViewContent, "a")
     
                

    def createAndAuthorizeViews(self, datasetDirPath, tfVarsAsPyObject):
        tables = tfVarsAsPyObject["tables"].keys()
        print("Processing", len(tables) ," tables under the dataset directory", datasetDirPath, "to create and Authorize view under thread name--->",threading.current_thread().name)
        for table in tfVarsAsPyObject["tables"].keys():
            jsonFileName = table+".json"
            sourceJsonFile = os.path.join(datasetDirPath,jsonFileName)
            viewDatasetDirPath = datasetDirPath + "_view"
            destinationJsonFile = os.path.join(viewDatasetDirPath,jsonFileName)
            #print("source json path", sourceJsonFile, "Destination json path",destinationJsonFile)
            if not os.path.isfile(viewDatasetDirPath):
                shutil.copyfile(sourceJsonFile, destinationJsonFile)
            #load json file and extract all columns 
            JSONFile = open(destinationJsonFile)
            JSONStr = JSONFile.read()
            JSONData = json.loads(JSONStr)
            columns = [column['name'] for column in JSONData]
            columns =  (', '.join(columns)).upper()
            # if copied then build sql
            queryBuilder = QueryBuilder(tfVarsAsPyObject["project_id"])
            sqlQuery = queryBuilder.buildSelectQuery(tfVarsAsPyObject["dataset_id"], table, columns)
            FileUtils.writeContentToFile(os.path.join(viewDatasetDirPath, table+".sql"), sqlQuery)
        #Authroize the view
        self.authorizeView(datasetDirPath, tfVarsAsPyObject)