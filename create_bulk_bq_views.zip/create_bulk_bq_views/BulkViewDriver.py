from TerraformUtil import *
import os
from QueryBuilder import *
from FileUtils import *
import sys
import logging as log
from inputimeout import inputimeout 
from DatasetTableViewsProcessor import *
from concurrent.futures import *
import time 


class BulkViewDriver:
    
    #Create Driver class object by supplying BQ path
    def __init__(self, bqDirectory):
        self.bqDirectory= bqDirectory

    #Create the content to add or modify the terraform vars for views
    def createViewTfVarsContent(self, terraformPath):
        tfVarUtil = TerraformUtil(terraformPath)
        viewTfVarsStr= None
        if not tfVarUtil.validateTerraform():
            log.error("Not valid terrafrom"+ terraformPath)
            self.tfVarsAsPyObject = None
            return
        tfVarsAsPyObject = tfVarUtil.convertTerrafromToPyObject()
        self.tfVarsAsPyObject = tfVarsAsPyObject
        correctOrder = ['template', 'project_id', 'dataset_id', 'location', 'deletion_protection', 'friendly_name', 'labels', 'access_config','access_config', 'kms_crypto_key', 'kms_project_id', 'kms_location', 'kms_key_ring', 'schema_dir', 'tables', 'views']
        viewTfUpdateVarDict = {}
        viewTfUpdateVarDict['dataset_id']= tfVarsAsPyObject['dataset_id']+"_view"
        viewTfUpdateVarDict['friendly_name'] = tfVarsAsPyObject['dataset_id']+"_view"
        viewTfUpdateVarDict['access_config'] = {}
        viewTfUpdateVarDict['tables'] = {}
        
        viewGroupRoleBinding = {"role": "roles/bigquery.dataViewer", "group_by_email":""}
        daBDBq= {"\"daDBQB\"": viewGroupRoleBinding}
        viewTfUpdateVarDict['access_config'] = daBDBq
        
        tableList = list(tfVarsAsPyObject['tables'].keys())
        formattedViewList = [f"\"{table}_view\"" for table in tableList]
        viewTfUpdateVarDict['views'] = formattedViewList
        viewTfVarsStr = TerraformUtil(terraformPath).buildViewTfvars(correctOrder, viewTfUpdateVarDict)
        return viewTfVarsStr
    
    #Join the folder and file path
    def joinPath(self,basePath, file):
        return os.path.join(basePath,file)
    
    def processViewsTf(self, dataset):
        log.info("Process dataset '"+ dataset +"' for view creation")
        datasetDir = self.joinPath(self.bqDirectory,dataset)
        viewTfContent = self.createViewTfVarsContent(self.joinPath(datasetDir,"terraform.tfvars"))
        
        if(viewTfContent is not None):
        #create view dataset
            viewDatasetDir = datasetDir + "_view"
            
            if not os.path.exists(viewDatasetDir):
                FileUtils.createDir(viewDatasetDir)
                log.info("View directory created : "+ viewDatasetDir)   
                        
            viewTfVarsPath = self.joinPath(viewDatasetDir, "terraform.tfvars")
            if not os.path.exists(viewTfVarsPath):
                FileUtils.writeContentToFile(viewTfVarsPath, viewTfContent)
                log.info("terraform vars file created: "+ viewTfVarsPath)
        else:
            self.discardDataset.append(dataset)
        return viewTfContent
            
            
    def processDatsetTableViews(self, datasets):
        procerror = DatasetTableViewsProcessor()
        #serial execution
        '''for dataset,tfvarPyObj in datasets.items():
            datasetPath = self.joinPath(self.bqDirectory,dataset)
            procerror = DatasetTableViewsProcessor()
            procerror.createAndAuthorizeViews(datasetPath, tfvarPyObj)'''
        
        #forking threads to submit the tasks
        print("######This machine has %s #cores"%os.cpu_count())
        with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
            futures = [executor.submit(procerror.createAndAuthorizeViews, self.joinPath(self.bqDirectory,dataset), tfvarPyObj) for dataset,tfvarPyObj in datasets.items()]
            wait(futures, None,  ALL_COMPLETED)
    
    def createBulkViews(self):
        # get the datasets folders iterator
        datasets = next(os.walk(self.bqDirectory))[1]
        log.info("All the datasets folders:"+ str(datasets))
        validDataset = {}
        self.discardDataset=[]
        start_time= time.time()      
        for dataset in datasets:
            #check if view set is available then dont process
            datasetPath =self.joinPath(self.bqDirectory,dataset)
            if(dataset in self.discardDataset or os.path.exists(datasetPath+"_view")):
                log.warn("Skipping the dataset "+dataset + " as its dataset_view directory aleady created")
                self.discardDataset.append(dataset)
                continue
            
            self.processViewsTf(dataset)
            if(self.tfVarsAsPyObject is not None):
                validDataset[dataset] = self.tfVarsAsPyObject
        if len(validDataset) >0:
            self.processDatsetTableViews(validDataset)
        print("Datasets discarded as its not eligible or their views already created --->", self.discardDataset)
        print("---Total time taken for the execution: %s seconds---" % (time.time() - start_time))
            

def takeManulaInput():
    bqDir = None
    try: 
        bqDir = inputimeout(prompt="Please provide the BQ directory full qualified path:", timeout=300) 
    except Exception:
        log.info("Please provide your input..  Try again")
    
    if bqDir is None:
        log.info("Exiting from "+sys.argv[0] +" script, Please provide your input and try again!")
    elif not os.path.exists(bqDir):
        log.error("Given BQ directory fully qualified path '"+ bqDir +"' is incorrect, Please try again!")
        bqDir = None
    return bqDir
        


if __name__ == "__main__":
    log.basicConfig(level=log.INFO)
    bqDir = None
    if len(sys.argv) > 1: 
        bqDir = sys.argv[1]
    else:
        bqDir = takeManulaInput()
    
    if bqDir is not None:
        BulkViewDriver(bqDir).createBulkViews()
        
        