class QueryBuilder:
    
    _SELECT_QUERY = "SELECT {columns} FROM {projectId}.{datasetId}.{table}"
    
    def __init__(self, project_id):
        self.project_id=project_id
        
    def buildSelectQuery(self, dataset_id, table, columns):
        if (dataset_id is None or dataset_id == "") or (table is None or table == "") or (columns is None or columns == ""):
            raise ValueError("QueryBuilder::Invalid query paramater supplied", dataset_id , table, columns)
        query = self._SELECT_QUERY.format(columns= columns, projectId=self.project_id, datasetId=dataset_id, table=table)
        return query