import hcl2
from pytfvars import tfvars
import os
import logging as log
from python_terraform import Terraform

class TerraformUtil:
    
    def __init__(self, terrfrom_var_file):
        self.terrfrom_var_file = terrfrom_var_file
          

    def __convertTfvarsToPyObject(self):
        with open(self.terrfrom_var_file, "r") as file:
            data = hcl2.load(file)
            return data
        
    def convertTerrafromToPyObject(self):
        tfvarsAsPyObject = self.__convertTfvarsToPyObject()
        return tfvarsAsPyObject
        
    def buildViewTfvars(self, tfVarsToCopy, varsToModifyForTFView):
        tvfDict= self.convertTerrafromToPyObject()
        viewTfvarsPyObject ={}  
        for key in tvfDict:
            if(key in tfVarsToCopy):
                if key in varsToModifyForTFView:
                    viewTfvarsPyObject[key] = varsToModifyForTFView.get(key)
                else:
                    viewTfvarsPyObject[key] = tvfDict.get(key)
            else:
                viewTfvarsPyObject[key] = varsToModifyForTFView.get(key)
        return tfvars.convert(viewTfvarsPyObject)
        
    def validateTerraform(self):
        if (not os.path.isfile(self.terrfrom_var_file)):
            log.warn("Skipping the view creation for the tvfvars file as: "+ self.terrfrom_var_file +" doesn't exist")
            return False
        tfvarDict= self.convertTerrafromToPyObject()
        if len(tfvarDict['tables']) == 0:
            log.info("Skipping the view creation as there is no table present: "+self.terrfrom_var_file)
            return False
        
        return True
    
    def getTfVarFromPyObject(self, authViewPyObject):
        return tfvars.convert(authViewPyObject)
        
            
             
        
        