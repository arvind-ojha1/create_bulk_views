# Create Bulk BQ Views Script
---
*Title: Create Bulk BQ Views*<br>
*Author: Arvind Ojha*<br>
*Email: <arvind.ojha1@lloydsbanking.com>*<br>
*Create On: 26 July, 2024*
---

## Purpose
The purpose of the script is to solve the problem of creating corresponding views for BQ tables.  
Currently we have thousands of BQ tables within hundreds of datasets in BQ that are all defined in terraform.tfvars files.  

The access model for BQ data has changed, so that users should only have access to data via a view, rather than direct access to a table (thus forcing read-only access).  

A view is just a SQL `select` statement, in this case we want the `select` statement to select all columns in the table. 
This script will scan a folder, identify any tables that are defined in a subfolder that don't already have a corresponding view created, and generete the code for a corresponding view. 

## How to use
Go to the script folder "create_bulk_bq_views" and then run the below command

### Activate the virtual environment by running the below command

```
Windows Machine: 
# In cmd.exe
"./venv/Scripts/activate.bat"
# In PowerShell
./venv/Scripts/Activate.ps1
#Linux and MacOS venv activation
source ./venv/Scripts/activate
```


### Run the script 
There are two ways you can run the script.

Method 1:
```
"./venv/Scripts/python" BulkViewDriver.py <BQ dataset path argument>

example: "./venv/Scripts/python" BulkViewDriver.py "./test-project/bld-01/data/bq"
```

Method 2:

If you don't provide the BQ dataset path as an argument in Method 1 then it will ask to manually enter the fully qualified path for bq dataset.If input is not provided then script exit after 5 minutes waiting.
```
"./venv/Scripts/python" BulkViewDriver.py
```