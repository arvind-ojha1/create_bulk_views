 SELECT                                                                         
 CAST(`avm_errorcode`.`application_cross_ref_id` as bigint) as `ApplicationCrossReferenceId`,                     
 CAST(substr(`avm_errorcode`.`omdm_timestamp`,1,19) as STRING) as `ApplicationTimestamp`,                    
 `avm_errorcode`.`transaction_id` as `ApplicationTransactionId`,                             
 `avm_errorcode`.`roll_number` as `MortgageReference`,                                       
 `avm_errorcode`.`submitter_id` as `SubmitterID`,                                            
 `avm_errorcode`.`error_value` as `ErrorValue`,                                                                   
 `avm_errorcode`.`edh_ingest_ts` as `PROCESSED_DTTM`,                                                             
 `avm_errorcode`.`ingestion_year`,                                                                                
 `avm_errorcode`.`ingestion_month`,                                                                               
 `avm_errorcode`.`ingestion_day`, 
 `avm_errorcode`.`edh_partition_dt` from `ap_enrcon_bld_01_bqd_euwe2_ccrdrsk_schema_omdm_al05943_01`.`avm_errorcode` where `avm_errorcode`.`rec_type`='O'  

