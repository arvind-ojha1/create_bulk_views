 SELECT                                                                   
 CAST(`avm_export`.`application_cross_ref_id` as INT64) as `ApplicationCrossReferenceId`,               
 substr(`avm_export`.`omdm_timestamp`,1,19) as `ApplicationTimestamp`,              
 `avm_export`.`transaction_id` as `ApplicationTransactionId`,                       
 `avm_export`.`roll_number` as `MortgageReference`,                                 
 `avm_export`.`submitter_id` as `SubmitterID`,                                      
 `avm_export`.`avm_eligible` as `AVMEligible`,                                       
 `avm_export`.`avm_acceptable` as `AVMAcceptable`,                                   
 `avm_export`.`avm_provider_id` as `AVMProviderID`,                                 
 `avm_export`.`avm_valuation_amount` as `ValuationAmount`,                                               
 `avm_export`.`avm_rental_income` as `rentalamount`,                                                     
 `avm_export`.`edh_ingest_ts` as `PROCESSED_DTTM`,                                                       
 `avm_export`.`ingestion_year`,                                                                          
 `avm_export`.`ingestion_month`,                                                                         
 `avm_export`.`ingestion_day`, 
 `avm_export`.`edh_partition_dt` from `ap_enrcon_bld_01_bqd_euwe2_ccrdrsk_schema_omdm_al05943_01`.`avm_export` where `avm_export`.`rec_type`='O'  

