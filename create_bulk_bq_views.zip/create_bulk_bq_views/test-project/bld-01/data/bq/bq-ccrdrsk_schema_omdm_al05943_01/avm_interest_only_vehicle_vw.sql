SELECT                                                                                                 
 CAST(`avm_interest_only_vehicle`.`application_cross_ref_id` as INT64) as `ApplicationCrossReferenceId`,                                             
 substr(`avm_interest_only_vehicle`.`omdm_timestamp`,1,19) as `ApplicationTimestamp`,                                            
 `avm_interest_only_vehicle`.`transaction_id` as `ApplicationTransactionId`,                                                     
 `avm_interest_only_vehicle`.`roll_number` as `MortgageReference`,                                                               
 `avm_interest_only_vehicle`.`submitter_id` as `SubmitterID`,                                                                    
 `avm_interest_only_vehicle`.`edh_ingest_ts` as `PROCESSED_DTTM`,                                                                                     
 `avm_interest_only_vehicle`.`repayment_vehicle_type` as `RepaymentVehicleType`,                                                                      
 `avm_interest_only_vehicle`.`repayment_vehicle_amount` as `RepaymentVehicleAmount`,                                                                  
 `avm_interest_only_vehicle`.`ingestion_year`,                                                                                                        
 `avm_interest_only_vehicle`.`ingestion_month`,                                                                                                       
 `avm_interest_only_vehicle`.`ingestion_day`, 
 `avm_interest_only_vehicle`.`edh_partition_dt` from `ap_enrcon_bld_01_bqd_euwe2_ccrdrsk_schema_omdm_al05943_01`.`avm_interest_only_vehicle` where `avm_interest_only_vehicle`.`rec_type`='O'  

